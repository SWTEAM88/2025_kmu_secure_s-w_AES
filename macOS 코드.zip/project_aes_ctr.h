#ifndef PROJECT_AES_CTR_H //헤더가 중복으로 포함되지 않도록 하는 가드 매크로
#define PROJECT_AES_CTR_H

#include <stdint.h>
#include <stddef.h>

// 타입 정의
typedef uint8_t  byte;  // 암호화용 8비트 자료형
typedef uint32_t word;  // 암호화용 32비트 자료형

// AES 블록 크기 (128비트 = 16바이트)
#define AES_BLOCK_SIZE 16

// AES 매개변수
#define AES_NB 4   // 블록당 32비트 워드 수 (항상 4)
#define AES_NK_128 4  // AES-128: 키 길이 4워드 (16바이트)
#define AES_NK_192 6  // AES-192: 키 길이 6워드 (24바이트)
#define AES_NK_256 8  // AES-256: 키 길이 8워드 (32바이트)

#define AES_NR_128 10 // AES-128: 라운드 수
#define AES_NR_192 12 // AES-192: 라운드 수
#define AES_NR_256 14 // AES-256: 라운드 수

// SHA-256 해시컨텍스트 구조체
typedef struct {
    byte data[64];         // 입력 데이터의 버퍼
    uint32_t datalen;      // 현재 데이터의 길이
    uint64_t bitlen;       // 전체 입력 비트 길이
    uint32_t state[8];     // 해시 상태
} SHA256_CTX;

// AES 내부 함수 선언
int aes_keyexpansion(const byte* key, word* w, size_t key_len);

void aes_encrypt(byte input[16], byte output[16], const word* w, int Nr);
void aes_decrypt(byte input[16], byte output[16], const word* w, int Nr);

// AES 고수준 모드 함수 선언
// encrypt: 1=암호화, 0=복호화
void AES_ECB(const byte* input, byte* output, size_t length,
    const byte* key, size_t key_len, int encrypt);

void AES_CBC(const byte* input, byte* output, size_t length,
    const byte* key, const byte* iv, size_t key_len, int encrypt);

void AES_CTR(const byte* input, byte* output, size_t length,
    const byte* key, const byte* nonce, size_t key_len);

// SHA-256 함수 선언
void sha256_init(SHA256_CTX* ctx);
void sha256_update(SHA256_CTX* ctx, const byte data[], size_t len);
void sha256_final(SHA256_CTX* ctx, byte hash[]);
void sha256(const byte data[], size_t len, byte hash[]);

// 보안키 생성 함수
int generate_secure_key(byte* key, size_t key_len);

#endif // PROJECT_AES_CTR_H